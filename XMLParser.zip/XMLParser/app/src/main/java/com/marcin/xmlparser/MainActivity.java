package com.marcin.xmlparser;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import org.xml.sax.InputSource;
import org.xml.sax.XMLReader;

import java.io.BufferedReader;
import java.io.StringReader;
import java.util.List;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

public class MainActivity extends AppCompatActivity {

    List<XMLValuesModel> myData = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView output =(TextView)findViewById(R.id.textView2);
        final Button bparsexml = (Button)findViewById(R.id.button);

        final String XMLData = "<?xml version=\"1.0\"?><login><status>OK</status><jobs><job><id>4</id><companyid>4</companyid><company>Android Example</company><address>Parse XML Android</address><city>Tokio</city><state>Xml Parsing Tutorial</state><zipcode>601301</zipcode><country>Japan</country><telephone>9287893558</telephone><fax>1234567890</fax><date>2012-03-15 12:00:00</date></job><job><id>5</id><companyid>6</companyid><company>Xml Parsing In Java</company><address>B-22</address><city>Cantabill</city><state>XML Parsing Basics</state><zipcode>201301</zipcode><country>America</country><telephone>9287893558</telephone><fax>1234567890</fax><date>2012-05-18 13:00:00</date></job></jobs></login>";

        output.setText(XMLData);

        bparsexml.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                try {

                    BufferedReader br = new BufferedReader(new StringReader(XMLData));
                    InputSource is = new InputSource(br);

                    XMLParser parser = new XMLParser();

                    SAXParserFactory factory = SAXParserFactory.newInstance();

                    SAXParser sp = factory.newSAXParser();
                    XMLReader reader = sp.getXMLReader();

                    reader.setContentHandler(parser);
                    reader.parse(is);

                    myData = parser.list;

                    if(myData!=null)
                    {
                        String OutputData = "";
                        for(XMLValuesModel xmlRowData: myData) {

                            if(xmlRowData!=null) {

                                int id = xmlRowData.getId();
                                int comapnyid = xmlRowData.getCompany_id();
                                String company = xmlRowData.getCompany();
                                String address = xmlRowData.getAddress();
                                String city = xmlRowData.getCity();
                                String state = xmlRowData.getState();
                                String zipcode = xmlRowData.getZipcode();
                                String country = xmlRowData.getCountry();
                                String telephone = xmlRowData.getTelephone();
                                String date = xmlRowData.getDate();

                                OutputData += "Węzły XML: \n\n" + company + "|"
                                        +address+"|"
                                        +city+"|"
                                        +state + "|"
                                        +zipcode + "|"
                                        +country + "|"
                                        +telephone + "|"
                                        +date+"|";

                            }
                            else
                                output.setText("brak danych");


                        }
                        output.setText(OutputData);
                    }
                }
                catch (Exception e)
                {
                    output.setText("Błąd Parsowania!" + e);
                }
            }
        });
    }
}
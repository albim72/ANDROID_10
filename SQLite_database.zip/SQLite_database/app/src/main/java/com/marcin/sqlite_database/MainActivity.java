package com.marcin.sqlite_database;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;
import android.widget.TextView;

import java.util.List;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        final TextView txt = (TextView)findViewById(R.id.tvDBWynik);

        DatabaseHandler db = new DatabaseHandler(this);
        db.addContact(new Contact("Robert","5345345543"));
        db.addContact(new Contact("Olga","875634564"));
        db.addContact(new Contact("Ala","56456435456546"));
        db.addContact(new Contact("Piotr","24123424543"));
        db.addContact(new Contact("Leon","243456565"));
        db.addContact(new Contact("Janina","54356546"));

        txt.setText("czytanie wszystkich kontaktów: ");
        List<Contact> contacts = db.getAllContacts();

        for (Contact cn:contacts) {
            String log = "ID: " + cn.getId() + ", Imię: " + cn.getName() + ", telefon: " +
                    cn.getPhone() + "\n\r";
            txt.setText(txt.getText() + "\n Osoba: " + log);
        }

    }
}